'use strict';
const http = require('http');
const crypto = require('crypto');
const WebSocket = require('ws');
const PORT = Number(process.env.PORT || 3000);
const MAX_PLAYERS = 8;
const rooms = new Map();
const clients = new Map();
const cleanCode = s => String(s || '').toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 12);
const cleanName = s => String(s || 'Player').replace(/[<>\u0000-\u001f]/g, '').trim().slice(0, 20) || 'Player';
function roomCode() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code;
  do { code = Array.from(crypto.randomBytes(5), b => alphabet[b % alphabet.length]).join(''); } while (rooms.has(code));
  return code;
}
function send(ws, data) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data)); }
function broadcast(room, data, except) {
  for (const ws of room.members) if (ws !== except) send(ws, data);
}
function leave(ws) {
  const info = clients.get(ws); if (!info) return;
  const room = rooms.get(info.room);
  if (room) {
    room.members.delete(ws);
    broadcast(room, { type: 'peer-left', id: info.id, name: info.name });
    if (room.members.size === 0) rooms.delete(info.room);
  }
  clients.delete(ws);
}
const server = http.createServer((req, res) => {
  if (req.url === '/health' || req.url === '/') {
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'access-control-allow-origin': '*' });
    res.end(JSON.stringify({ name: 'Scrapyard Sandbox Multiplayer Server', status: 'ok', rooms: rooms.size, players: clients.size, maxPlayersPerRoom: MAX_PLAYERS }));
  } else { res.writeHead(404); res.end('Not found'); }
});
const wss = new WebSocket.Server({ server, maxPayload: 16 * 1024 });
wss.on('connection', ws => {
  ws.isAlive = true;
  ws.on('pong', () => { ws.isAlive = true; });
  ws.on('message', raw => {
    let msg; try { msg = JSON.parse(raw.toString()); } catch { return send(ws, { type: 'error', message: 'Invalid JSON.' }); }
    if (!msg || typeof msg.type !== 'string') return;
    if (msg.type === 'join') {
      if (clients.has(ws)) return send(ws, { type: 'error', message: 'You are already in a room.' });
      const requested = cleanCode(msg.room);
      const code = requested || roomCode();
      let room = rooms.get(code);
      if (!room) { room = { members: new Set() }; rooms.set(code, room); }
      if (room.members.size >= MAX_PLAYERS) return send(ws, { type: 'error', message: 'That room is full (maximum 8 players).' });
      const info = { id: crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(12).toString('hex'), room: code, name: cleanName(msg.name), state: null, joinedAt: Date.now() };
      clients.set(ws, info); room.members.add(ws);
      send(ws, { type: 'joined', id: info.id, room: code, players: room.members.size });
      for (const other of room.members) {
        if (other === ws) continue;
        const oi = clients.get(other);
        if (oi) {
          send(ws, { type: 'state', id: oi.id, state: oi.state || { name: oi.name, x: 0, y: 1, z: 0, yaw: 0, pitch: 0, hp: 100, weapon: 'pistol', map: 'yard' } });
          send(other, { type: 'peer-joined', id: info.id, name: info.name });
        }
      }
      return;
    }
    const info = clients.get(ws); if (!info) return send(ws, { type: 'error', message: 'Join a room first.' });
    if (msg.type === 'state') {
      const s = msg.state || {};
      const finite = v => Number.isFinite(Number(v)) ? Math.max(-100000, Math.min(100000, Number(v))) : 0;
      info.state = { name: info.name, x: finite(s.x), y: finite(s.y), z: finite(s.z), yaw: finite(s.yaw), pitch: finite(s.pitch), hp: Math.max(0, Math.min(1000, finite(s.hp))), weapon: String(s.weapon || 'pistol').slice(0, 24), map: String(s.map || 'yard').slice(0, 32) };
      const room = rooms.get(info.room); if (room) broadcast(room, { type: 'state', id: info.id, state: info.state }, ws);
    }
  });
  ws.on('close', () => leave(ws));
  ws.on('error', () => leave(ws));
});
const heartbeat = setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive) { ws.terminate(); continue; }
    ws.isAlive = false; ws.ping();
  }
}, 30000);
wss.on('close', () => clearInterval(heartbeat));
server.listen(PORT, '0.0.0.0', () => console.log(`Scrapyard multiplayer server listening on port ${PORT}`));
