SCRAPYARD SANDBOX — MULTIPLAYER STARTER (PHASE 1)
================================================

WHAT THIS BUILD DOES
- Adds a Multiplayer panel to the game.
- Supports room codes, up to 8 players per room, LAN WebSocket connections, and secure WebSocket URLs for an online-hosted server.
- Synchronizes player position and facing direction; other players appear as simple visible avatars with name labels.
- Keeps the original single-player game available.

IMPORTANT LIMITATION
This is the first multiplayer foundation, not full shared-world synchronization yet. NPC AI/health, props, vehicles, bullets/damage, dismemberment, map changes, and physics objects are still local to each browser and are NOT authoritative/shared. Players should select the same map themselves. Do not treat this as finished full Garry's Mod-style multiplayer.

FILES
- Scrapyard_Sandbox_Multiplayer.html : modified game
- server.js / package.json : room relay server

RUN ON A COMPUTER (LAN)
1. Install Node.js 18 or newer.
2. Put server.js and package.json in the same folder.
3. Open a terminal in that folder and run: npm install
4. Run: npm start
5. Find the host computer's LAN IPv4 address (for example 192.168.1.25). Allow Node.js through the computer firewall on private networks.
6. Open the HTML game on each device. In Multiplayer, enter ws://192.168.1.25:3000 (replace with the host's actual IP).
7. One player presses Create room. Share the displayed room code. Others enter the same server address and room code, then press Join room.

NOTE: ws://localhost:3000 only connects to the same device. On phones, use the computer's LAN IP, not localhost.

ONLINE HOSTING
1. Deploy server.js and package.json as a Node web service on a host that supports persistent WebSockets.
2. The service must use the assigned PORT environment variable (this server does).
3. Use the secure wss:// address supplied by your host in the game panel.
4. Anyone with the server address and room code can try to join; use only with people you trust. This starter has no account system or room password.

TROUBLESHOOTING
- If connection fails on Wi-Fi, ensure both devices use the same LAN, the server is running, the IP is correct, and the firewall allows the port.
- If an online host provides https://, use its matching wss:// WebSocket address in the game.
- This HTML loads Three.js and Cannon.js from CDNs, so the first launch needs internet access for those libraries.
